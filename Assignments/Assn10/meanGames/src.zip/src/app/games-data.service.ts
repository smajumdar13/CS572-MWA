// first system dependencies
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

// second application dependencies
import { Game } from './games-list/games-list.component';

// third declarations
@Injectable({
  providedIn: 'root',
})

// fourth exports
export class GamesDataService {
  private baseURL: string = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {} // shortcut telling TS to create HTTP which is a private attribute
  // The value of this attribute is injected by the environment

  public getGames(): Promise<Game[]> {
    // 1. Build URL
    const url: string = this.baseURL + '/games';

    // 2. Tell HTTP service to make a request to
    // 3. Convert the Observable result to a promise
    // 4. Convert the response to JSON
    // 5. Return the response object
    // 6. Catch and handle errors
    return this.http
      .get(url)
      .toPromise()
      .then(this.gotGames)
      .catch(this.handleError);
  }

  private gotGames(response: any) {
    // can add :Game[] to the end of (response: any)
    return response as Game[];
  }

  private handleError(error: any) {
    // can add :Game[] to the end of (error: any)
    console.log('Error', error);
    return [];
  }

  public getGame(gameId: string): Promise<Game> {
    const url: string = this.baseURL + '/game/' + gameId;

    return this.http
      .get(url)
      .toPromise()
      .then(this.gotGame)
      .catch(this.handleOneError);
  }

  private gotGame(response: any) {
    return response as Game;
  }

  private handleOneError(error: any) {
    console.log('Error', error);
    return {} as Game;
  }
}
