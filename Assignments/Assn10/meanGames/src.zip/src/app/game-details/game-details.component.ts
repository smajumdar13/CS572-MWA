import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { GamesDataService } from '../games-data.service';
import { Game } from '../games-list/games-list.component';

@Component({
  selector: 'app-game-details',
  templateUrl: './game-details.component.html',
  styleUrls: ['./game-details.component.css'],
})
export class GameDetailsComponent implements OnInit {
  title: string = 'Mean Games One';

  game: Game = {} as Game;

  constructor(
    private gamesDataService: GamesDataService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const gameId = this.route.snapshot.params.gameId;
    this.getGame(gameId);
  }

  private getGame(gameId: string): void {
    this.gamesDataService
      .getGame(gameId)
      .then((response) => this.gotGame(response))
      .catch(this.handleError);
  }

  private gotGame(response: Game) {
    console.log(response);
    this.game = response;
  }

  private handleError(error: any) {
    console.log(error);
  }
}
